import textract
import re
import pandas as pd
import file_list as files

def extractTextFromPdf(mypath, df):
    list_files=files.list_filenames(mypath)
    for f in list_files:
        text_from_pdf = textract.process(mypath+f,extension='pdf')
        #put text in lowercase
        text_lower = str(text_from_pdf).lower()
        
        #Extract paragraphs from text 
        client_name = f.split('_')[0]
        issue = regexp("issue","solution", text_lower)   
        solution=regexp("solution","benefits", text_lower)
        benefit=regexp("benefits","other details", text_lower)
        other_details=regexp("other details","", text_lower)
        vars=[f,client_name, issue, solution, benefit, other_details]
        df.loc[len(df.index)] = vars
    return df

    
def regexp(word1, word2, text):
    found =""
    m=re.search(word1+"(.*)"+word2, text, re.DOTALL)
    if m:
        found = m.group(1)
        #print(found)
    else:
        m=re.search(word1+"(.*)", text, re.DOTALL)
        if m:
            found = m.group(1)
        else:
            print('not found')
    return found

#pdt path, create pptToPdf/result folder before execution
mypath="/home/user_deep/sbensala/challenge/pptToPdf/"               
columns=['file_name','Client_name', 'Issue', "Solution", "Benefit","Other details"]
df = pd.DataFrame(columns=columns)   
df1=extractTextFromPdf(mypath, df)
result_path = '/home/user_deep/sbensala/challenge/pptToPdf/results/results.xlsx'
df1.to_excel(result_path, index=False)