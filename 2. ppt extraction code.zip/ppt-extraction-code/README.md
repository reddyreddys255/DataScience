#### What you have to install in a Linux machine to run this code


-------------------------- Convert ppt to pdf -------------------------------------
#To run shell script convert_ppt_to_pdf.sh, you have to install LibreOffice
sudo apt-get install libreoffice

#Open convert_ppt_to_pdf script, and change the variable declaration FILES
# Put in this variable the path to your ppt files folder

#Go to the folder where you want to put your pdf files using:
cd path_folder_for_pdf

#Thow that you are in the folder of destination of pdf files, exectute this command:
python folder_of_script_shell/convert_ppt_to_pdf.sh


-------------------------- Run text Extraction -------------------------------------
# To run text extraction extractText_tuto.py
1- Install textract python library 
pip install textract

#If an error related to swig, run this command, then run the commande described in 1- : 
sudo apt-get install python-dev libxml2-dev libxslt1-dev antiword unrtf poppler-utils pstotext tesseract-ocr \
flac ffmpeg lame libmad0 libsox-fmt-mp3 sox libjpeg-dev swig

#If you have an error related to gcc, run this command, then run the commande described in 1- : :
sudo apt-get install libpulse-dev

#When you finished installing textract , open the python scriot extractText_tuto.py
#You have to change some variable declarations : 
mypath = path_folder_for_pdf
result_path = path_for_excel_result
