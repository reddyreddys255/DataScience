from os import listdir
from os.path import isfile, join

def list_filenames(mypath):
    onlyfiles = [f for f in listdir(mypath) if isfile(join(mypath, f))]
    print(onlyfiles)
    for f in onlyfiles:
        print("----- : {}".format(f))
    return onlyfiles
